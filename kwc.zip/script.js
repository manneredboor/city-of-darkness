const canvas = document.querySelector('#canvas')
const ctx = canvas.getContext('2d')

//
// State
//

const state = {
  bgW: 1491,
  bgH: 1000,
  dot: { x: 0, y: 0 },
  isDown: false,
  mouse: { x: 0, y: 0 },
  winH: window.innerHeight,
  winW: window.innerWidth,
}

const updateSizes = () => {
  state.winW = window.innerWidth
  state.winH = window.innerHeight
  canvas.width = window.innerWidth
  canvas.height = window.innerHeight
}

updateSizes()

//
// Math
//

const getRatiosDiffs = () => {
  const { winW, winH, bgW, bgH } = state

  const winR = winW / winH
  const bgR = bgW / bgH

  const scale = winR < bgR ? bgH / winH : bgW / winW

  const diffX = (bgW - winW * scale) / 2
  const diffY = (bgH - winH * scale) / 2

  return { diffX, diffY, scale }
}

const saveDot = (x, y) => {
  const { diffX, diffY, scale } = getRatiosDiffs()
  return {
    x: (newX = scale * x + diffX),
    y: (newY = scale * y + diffY),
  }
}

const restoreDot = (x, y) => {
  const { diffX, diffY, scale } = getRatiosDiffs()
  return {
    x: (1 / scale) * (x - diffX),
    y: (1 / scale) * (y - diffY),
  }
}

//
// Canvas
//

const render = () => {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height)
  ctx.beginPath()
  const d = restoreDot(state.dot.x, state.dot.y)
  // console.log(d)
  ctx.arc(d.x, d.y, 2, 0, 2 * Math.PI, false)
  ctx.fillStyle = 'yellow'
  ctx.fill()
  window.requestAnimationFrame(render)
}

window.requestAnimationFrame(render)

//
// Handlers
//

canvas.addEventListener('mousemove', e => {
  const { mouse, isDown } = state
  mouse.x = e.pageX
  mouse.y = e.pageY
  if (isDown) state.dot = saveDot(mouse.x, mouse.y)
})

window.addEventListener('resize', e => {
  updateSizes()
})

canvas.addEventListener('mousedown', e => {
  state.isDown = true
  state.dot = saveDot(state.mouse.x, state.mouse.y)
})

canvas.addEventListener('mouseup', e => {
  state.isDown = false
})
